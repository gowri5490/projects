package HandlingGSD;
import org.testng.annotations.AfterClass;
import org.testng.annotations.Test;
import org.testng.annotations.BeforeClass;

import io.github.bonigarcia.wdm.WebDriverManager;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Parameters;

import java.io.IOException;
import java.time.Duration;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;

public class GSD_Test {
	WebDriver driver;
	PageForHandlingGSD ph;
	
	@BeforeClass
	@Parameters({"browser"})
	public void setup(String br) throws InterruptedException {
		if(br.equals("chrome")) {
			WebDriverManager.chromedriver().setup();
			driver = new ChromeDriver();
		}
		else if(br.equals("edge")) {
			WebDriverManager.edgedriver().setup();
			driver = new EdgeDriver();
		}
		
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		driver.get("https://be.cognizant.com/");
		driver.manage().window().maximize();
		Thread.sleep(10000);	
	}
	
	@Test(priority = 1)
	public void profileCheck() throws InterruptedException, IOException {
		ph = new PageForHandlingGSD(driver);
		ph.checkProfile();
	}
	
	@Test(priority = 2, dependsOnMethods = {"profileCheck"})
	public void extractDetails() throws InterruptedException, IOException {
		ph.getProfileDetails();
	}
	
	@Test(priority = 3)
	public void oneCognClick() throws IOException {
		ph.clickOnOneCogn();
	}
	
	@Test(priority = 4, dependsOnMethods = {"oneCognClick"})
	public void switchingTabs() {
		ph.switchingWindow();		
	}
	
	@Test(priority = 5, dependsOnMethods = {"switchingTabs"})
	public void gsdSearch() throws InterruptedException, IOException {
		ph.searchGSD();
	}
	
	@Test(priority = 6, dependsOnMethods = {"gsdSearch"})
	public void clickingOnGsdLive() throws InterruptedException, IOException {
		ph.clickOnLive();
	}
	
	@Test(priority = 7, dependsOnMethods = {"clickingOnGsdLive"})
	public void getMessage() throws IOException {
		ph.validateWelcomeMessage();
	}
	
	@Test(priority = 8, dependsOnMethods = {"clickingOnGsdLive"})
	public void validateFirstLanguage() throws IOException {		
		ph.validateLanguage();
	}
	
	@Test(priority = 9, dependsOnMethods = {"clickingOnGsdLive"})
	public void validateFirstCountry() throws IOException {
		ph.validateCountry();
	}
	
	@Test(priority = 10, dependsOnMethods = {"clickingOnGsdLive"})
	public void getAllLanguageDetails() throws IOException {
		ph.languageDropDown();
	}
	
	@Test(priority = 11, dependsOnMethods = {"clickingOnGsdLive"})
	public void mouseHoverDetails() throws IOException{
		ph.hoverMouse();
	}

	@Test(dataProvider ="dp",priority = 12, dependsOnMethods = {"clickingOnGsdLive"})
	public void changeCountryFromDropDown(String countryNameToSelect) throws InterruptedException, IOException {
		ph.countryChange(countryNameToSelect);
		ph.hoverMouse();
	}
	
	@AfterClass
	public void closing() {
		ph.closeDriver();
	}
	
	@DataProvider(name = "dp")
	String [][] countryChangeData() throws IOException{
		String data[][]= ph.countryValues();
		return data;
	}
}
