package HandlingGSD;

import excelUtils.Excel;
import Screenshoots.ScreenShots;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;


import org.openqa.selenium.By;
import org.openqa.selenium.Keys;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.testng.Assert;

public class PageForHandlingGSD {
	//WebDriver and ScreenShots Instance
	public WebDriver driver;
	ScreenShots ss;
	
	//Setting up driver
	PageForHandlingGSD(WebDriver driver){
		this.driver=driver;
	}	
	
	// Calling Excel Object
	Excel xl = new Excel();
	
	//Locators
	By profile = By.xpath("//*[@id=\"O365_MainLink_MePhoto\"]/div/div/div/div/div[2]");
	By proName = By.id("mectrl_currentAccount_primary");
	By proId= By.id("mectrl_currentAccount_secondary") ;
	By oneClick = By.xpath("//*[@id=\"QuicklinksItemTitle\"]");
	By searchBar = By.id("oneC_searchAutoComplete");
	By liveSupportBtn = By.xpath("//*[@id=\"newSearchAppsLST\"]/div/div");
	By welComeMsg = By.xpath("//*[@id=\"ui-view\"]/div/div[3]/p[1]");
	By countryPath = By.xpath("//*[@id=\"menu2\"]/span");      
	By countryBtnClick = By.xpath("//*[@id=\"menu2\"]");
	By languageBtnClick = By.xpath("//*[@id=\"menu1\"]/span");
	By languageDrp = By.xpath("/html/body/nav[1]/div/form/div[1]/ul/li/a");
	By countryDrp = By.xpath("/html/body/nav[1]/div/form/div[2]/ul/li/a");
	

	// Method to check the profile
	public void checkProfile() throws InterruptedException, IOException {
		System.out.println("____INITIATED CHECKPROFILE____");
		Thread.sleep(2000);
		driver.findElement(profile).click();
		ss = new ScreenShots(driver);
		ss.screenShoot();
	}
	
	//Method to get the profile details
	public void getProfileDetails() throws InterruptedException {
		String proIdReturn  = driver.findElement(proId).getText();
		String proNameReturn  = driver.findElement(proName).getText();
		Thread.sleep(2000);
		System.out.println(proIdReturn);
		System.out.println(proNameReturn);
		System.out.println();
	}
	
	//Method to click on OneCognizant link
	public void clickOnOneCogn() {
		List<WebElement> wbc = driver.findElements(oneClick);
		for(WebElement wble:wbc) {
			if(wble.getText().equals("OneCognizant")) {
				wble.click();
			}
		}
		System.out.println("Clicked on one cogn\n");
	}
	
	//Method to switch tabs
	public void switchingWindow() {
		List<String> winIds = new ArrayList<String>(driver.getWindowHandles());
		String childId = winIds.get(1);
		driver.switchTo().window(childId);
	}
	
	//Method to search GSD in search bar
	public void searchGSD() throws InterruptedException, IOException {
		driver.findElement(searchBar).click();
		driver.findElement(searchBar).sendKeys(xl.sendSearchKeyX());
		Actions act =new Actions(driver);
        act.keyDown(Keys.RETURN).keyUp(Keys.RETURN).perform();
        Thread.sleep(3000);
        ss.screenShoot();
	}

	//Method to click on GSD Live Application
	public void clickOnLive() throws InterruptedException {
		driver.findElement(liveSupportBtn).click();
		Thread.sleep(20000);
	}
	
	//Method to validate Welcome message
	public void validateWelcomeMessage() throws IOException {
		driver.switchTo().frame("appFrame");
		String msg = driver.findElement(welComeMsg).getText();
		ss.screenShoot();
		Assert.assertEquals(msg, xl.validateWelcomeMsgX());
	}
	
	//Method to validate Language
	public void validateLanguage() throws IOException {
		String lang = driver.findElement(languageBtnClick).getText();
		Assert.assertEquals(lang, xl.validateLanguageX());
	}
	
	//Method to validate Country
	public void validateCountry() throws IOException {
		String country = driver.findElement(countryPath).getText();
		Assert.assertEquals(country, xl.validateCountryX());
	}
	
	//Method to handle language drop-down
	public void languageDropDown() throws IOException {
		driver.findElement(languageBtnClick).click();
		ss.screenShoot();
		List<WebElement> drp = driver.findElements(languageDrp);
		for(WebElement ff: drp) {
			System.out.println(ff.getText());
		}
		System.out.println();
	}
	
	//Method to hover the mouse over elements and capture data
	public void hoverMouse() throws IOException {
		String[][] dataNValue = new String[7][2];
		String countryCurrent = driver.findElement(countryPath).getText();
		System.out.println("+++++++"+countryCurrent+"+++++++\n");
		for(int i=1;i<=4;i++) {
			System.out.println("__________Next Section__________\n");
			for(int j=1;j<=7;j++) {
				if(i==4 && j==6) {
					break;
				}
				String titleText = driver.findElement(By.xpath("//*[@id='ui-view']/div/div[5]"
						+ "/div/div/div["+i+"]/div/div/div["+j+"]/div")).getText();
				String textHover = driver.findElement(By.xpath("//*[@id='ui-view']/div/div[5]"
						+ "/div/div/div["+i+"]/div/div/div["+j+"]/div")).getAttribute("data-bs-original-title");
				System.out.println(titleText +"  ---  "+ textHover);
				dataNValue[j-1][0]=titleText;
				dataNValue[j-1][1]=textHover;
			}
			System.out.println(" ");
		}
	}
	
	// Method to change the country in the application
	public void countryChange(String cName) throws InterruptedException, IOException {
		driver.findElement(countryBtnClick).click();
		List <WebElement> listDrpArray = driver.findElements(countryDrp);
		for(WebElement ele:listDrpArray) {
			String cc = ele.getText();
			if(cc.equals(cName)) {
				ele.click();
				Thread.sleep(2000);
				ss.screenShoot();
			}
		}
	}
	
	// Method to get country values from Excel
	public String [][] countryValues() throws IOException{
		return xl.changeLocX();
	}
	
	// Method to close the WebDriver instance
	public void closeDriver() {
		driver.quit();
	}
}

