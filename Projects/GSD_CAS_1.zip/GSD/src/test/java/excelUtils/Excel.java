package excelUtils;

import java.io.FileInputStream;

import java.io.IOException;

import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;


public class Excel {
	
	//Workbook and FileInputStream instance
	private Workbook wb;
	private FileInputStream file;
	
	// Variable to store the row size
	private int rowsize;
	
	// Method to open the input Excel file and return the sheet
	public Sheet openInputFile() throws IOException {
	file = new FileInputStream("C:\\Users\\2320203\\eclipse-workspace\\GSD\\src\\Input\\Book1.xlsx");
	wb = new XSSFWorkbook(file);
	Sheet sheet = wb.getSheet("Sheet1");
	return sheet;
	}
	
	// Method to get the search key from the Excel file
	public String sendSearchKeyX() throws IOException {
		Sheet sheet = openInputFile();
		Row r = sheet.getRow(0);
		String value = r.getCell(0).toString();
		return value;
	}
	
	// Method to validate the welcome message from the Excel file
	public String validateWelcomeMsgX() throws IOException {
		Sheet sheet = openInputFile();
		Row r = sheet.getRow(0);
		String value = r.getCell(1).toString();
		return value;
	}
	
	// Method to validate the language from the Excel file
	public String validateLanguageX() throws IOException {
		Sheet sheet = openInputFile();
		Row r = sheet.getRow(0);
		String value = r.getCell(2).toString();
		return value;
	}
	
	// Method to validate the country from the Excel file
	public String validateCountryX() throws IOException {
		Sheet sheet = openInputFile();
		Row r = sheet.getRow(0);
		String value = r.getCell(3).toString();
		return value;
	}
	
	// Method to change the location values from the Excel file
	public String[][] changeLocX() throws IOException {
		Sheet sheet = openInputFile();
		Row r = sheet.getRow(1);
		rowsize = r.getLastCellNum();
		String[][] arr = new String[rowsize][1];
		for(int i=0;i<rowsize;i++) {
			arr[i][0] =  r.getCell(i).toString();
		}
		wb.close();
		file.close();
		return arr;
	}
}
