package Test_Base;

import java.io.FileInputStream;
import java.io.IOException;
import java.time.Duration;
import java.util.Properties;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Parameters;


public class BaseClass {

	public WebDriver driver;
	public Properties p;
	
	@BeforeClass
	@Parameters({"browser"})
	public void setup(String browser) throws InterruptedException, IOException
	{
		//loading property file
		FileInputStream file= new FileInputStream("C:\\Users\\2319992\\OneDrive - Cognizant\\Desktop\\Global_IT\\Global_IT\\src\\test\\resources\\config.properties");
		p= new Properties();
		p.load(file);
		if(browser.equalsIgnoreCase("chrome"))
		{
			driver = new ChromeDriver();
			//driver.manage().deleteAllCookies();
			driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
			//driver.get(" https://be.cognizant.com");
			driver.get(p.getProperty("openURL"));
			
			driver.manage().window().maximize();

		}
		else if(browser.equalsIgnoreCase("edge"))
		{
			driver = new EdgeDriver();
			driver.manage().deleteAllCookies();
			driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
			//driver.get(" https://be.cognizant.com");
			driver.get(p.getProperty("openURL"));
			driver.manage().window().maximize();
		}
		
	}
	
	@AfterClass
	public void tear_down()
	{
		driver.quit();
	}
	

	
	
}
