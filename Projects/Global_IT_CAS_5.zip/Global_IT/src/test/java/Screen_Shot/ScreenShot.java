package Screen_Shot;

import java.io.File;
import java.io.IOException;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.google.common.io.Files;

public class ScreenShot {
	static int screenShotNumber=1;
	public static void getScreenShot(WebDriver driver) throws IOException
	{
		File source=((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
		String path="C:\\Users\\2319992\\OneDrive - Cognizant\\Desktop\\Global_IT\\Global_IT\\src\\test\\java\\Screen_Shot\\pics\\webpage" + (screenShotNumber++) + ".png";
		File destination=new File(path);
		Files.copy(source, destination);
	}

	
	static int shot = 1;
	public static void webelement_screenshot(WebElement element) throws IOException
	{
		File src = element.getScreenshotAs(OutputType.FILE);
		File target = new File("C:\\Users\\2319992\\OneDrive - Cognizant\\Desktop\\Global_IT\\Global_IT\\src\\test\\java\\Screen_Shot\\pics\\webelement" + (shot++) + ".png");
		FileUtils.copyFile(src, target);
	}
}

