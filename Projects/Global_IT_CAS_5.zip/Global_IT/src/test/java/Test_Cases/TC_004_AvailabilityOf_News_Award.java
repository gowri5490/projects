package Test_Cases;

import java.io.IOException;

import org.testng.Assert;
import org.testng.annotations.Test;

import Page_Object.Global_ITPage;
import Page_Object.HomePage;
import Test_Base.BaseClass;

public class TC_004_AvailabilityOf_News_Award extends BaseClass{
	
	HomePage hp;
	Global_ITPage gitp;
	
	@Test(priority=0)
	public void checkAvailability_ITNews() throws InterruptedException, IOException
	{
		hp = new HomePage(driver);
		gitp = new Global_ITPage(driver);
		
		hp.click_CorporateFunction_IT();
		
		if(gitp.ITNews().isDisplayed())
		{
			Assert.assertTrue(true);
		}
		else
		{
			Assert.fail();
		}
		
	}
	
	@Test(priority=1)
	public void checkAvailability_ITAwards() throws InterruptedException, IOException
	{	
		if(gitp.ITAwards().isDisplayed())
		{
			Assert.assertTrue(true);
		}
		else
		{
			Assert.fail();
		}
		
	}

}
