package Test_Cases;

import java.io.IOException;

import org.testng.Assert;
import org.testng.annotations.Test;

import Excel.Excel;
import Page_Object.Global_ITPage;
import Page_Object.HomePage;
import Test_Base.BaseClass;

public class TC_006_Extract_AwardContent extends BaseClass{

	HomePage hp;
	Global_ITPage gitp;
	
	@Test(priority=0)
	public void validate_AwardContent() throws InterruptedException, IOException
	{
		hp = new HomePage(driver);
		gitp = new Global_ITPage(driver);
		
		hp.click_CorporateFunction_IT();
		
		if(gitp.ExtractAllAwards()==true)
		{
			Assert.assertTrue(true);
		}
		else
		{
			Assert.fail();
		}
	}
	
	@Test(priority=1,dependsOnMethods= {"validate_AwardContent"})
	public void check_AwardExcelContent() throws IOException
	{
		if(Excel.check_ExcelFile(2)==false)
		{
			Assert.assertTrue(true);
		}
		else
		{
			Assert.fail();
		}
	}
}
