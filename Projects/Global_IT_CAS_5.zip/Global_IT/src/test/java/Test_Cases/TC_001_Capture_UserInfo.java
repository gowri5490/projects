package Test_Cases;

import java.io.IOException;

import org.testng.Assert;
import org.testng.annotations.Test;

import Excel.Excel;
import Page_Object.HomePage;
import Test_Base.BaseClass;

public class TC_001_Capture_UserInfo extends BaseClass{
	
	HomePage hp; 
			
	@Test(priority=0)
	public void userInfo_btn() throws InterruptedException
	{
		try 
		{
			hp = new HomePage(driver);
			hp.info_btn_click();
		}
		catch(Exception e)
		{
			Assert.fail();
		}		
	}
	
	@Test(priority=1,dependsOnMethods= {"userInfo_btn"})
	public void higlight_userInfo() throws InterruptedException
	{
		try 
		{
			hp.Higlight_UserInfo();
		}
		catch(Exception e)
		{
			Assert.fail();
		}		
	}
	
	@Test(priority=2,dependsOnMethods= {"userInfo_btn"})
	public void fetching_userInfo() throws InterruptedException
	{
		try 
		{
			hp.fetching_userDetails();
		}
		catch(Exception e)
		{
			Assert.fail();
		}		
	}
	
	@Test(priority=3,dependsOnMethods= {"fetching_userInfo()"})
	public void check_UserExcelContent() throws IOException
	{
		if(Excel.check_ExcelFile(1)==false)
		{
			Assert.assertTrue(true);
		}
		else
		{
			Assert.fail();
		}
	}

}
