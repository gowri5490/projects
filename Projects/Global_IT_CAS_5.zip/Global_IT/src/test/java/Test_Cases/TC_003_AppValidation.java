package Test_Cases;

import org.testng.Assert;
import org.testng.annotations.Test;

import Page_Object.Global_ITPage;
import Page_Object.HomePage;
import Test_Base.BaseClass;

public class TC_003_AppValidation extends BaseClass{
	
	HomePage hp;
	Global_ITPage gitp;
	
	@Test(priority=0)
	public void validationOfAppPresent()
	{
		try {
			hp = new HomePage(driver);
			gitp = new Global_ITPage(driver);
			hp.click_CorporateFunction_IT();
			Assert.assertEquals(gitp.validate_appName(), true);
		}
		catch(Exception e) {
			
		}
	}

}
