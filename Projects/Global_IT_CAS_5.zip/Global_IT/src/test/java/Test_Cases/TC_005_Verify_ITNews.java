package Test_Cases;

import java.io.IOException;
import java.util.List;

import org.openqa.selenium.WebElement;
import org.testng.Assert;
import org.testng.annotations.Test;

import Page_Object.Global_ITPage;
import Page_Object.HomePage;
import Test_Base.BaseClass;

public class TC_005_Verify_ITNews extends BaseClass{
	
	HomePage hp;
	Global_ITPage gitp;
	
	@Test(priority=0)
	public void validate_NewsHeader_vs_Tooltip() throws InterruptedException, IOException
	{
		hp = new HomePage(driver);
		gitp = new Global_ITPage(driver);
		
		hp.click_CorporateFunction_IT();
		
		try {
			List<WebElement> list = gitp.News_HeaderTooltip();
			// compare tooltip with header
			   for(WebElement i : list)
			   {
				   Assert.assertEquals(i.getAttribute("title"), i.getText());			   
			   }
		}
		catch(Exception e) {
			
		}
	}

}
