package Test_Cases;

import org.testng.Assert;
import org.testng.annotations.Test;
import Page_Object.HomePage;
import Screen_Shot.ScreenShot;
import Test_Base.BaseClass;

public class TC_002_MouseHoverAction extends BaseClass{
	
	// WebDriver driver;
	HomePage hp;
	
	@Test(priority=100)
	public void corporateFunction_btn() throws InterruptedException
	{
		try 
		{
			hp = new HomePage(driver);
			hp.click_CorporateFunction_IT();
			
			ScreenShot.getScreenShot(driver);
			
			Assert.assertEquals(driver.getTitle(),"Global IT");
		}
		catch(Exception e)
		{
			
		}
			
	}
}
