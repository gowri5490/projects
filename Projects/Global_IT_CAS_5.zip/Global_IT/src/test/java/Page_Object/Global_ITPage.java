package Page_Object;

import java.io.IOException;
import java.time.Duration;
import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import Excel.Excel;
import Screen_Shot.ScreenShot;

public class Global_ITPage extends BasePage{

	WebDriverWait myWait;
	JavascriptExecutor js;

	//--------------------------CONSTRUCTOR--------------------------->>>>>>>>>>>>>>>>>>
	public Global_ITPage(WebDriver driver) {
		super(driver);
		myWait = new WebDriverWait(driver,Duration.ofSeconds(10));
		js=(JavascriptExecutor)driver;
	}
	//---------------------------------------------------------------->>>>>>>>>>>>>>>>>>

	
	//--------------------------PAGE OBJECT ELEMENTS--------------------------->>>>>>>>>>>>>>>>>>
	@FindBy(xpath="//*[@id=\\\"vpc_WebPart.HeroWebPart.internal.0ade8057-06f4-4d58-b81d-6986c9e3c7ac\\\"]//div[@role=\\\"listitem\\\"]//div[@data-automation-id=\\\"HeroTitle\\\"]")
	List<WebElement> apps;

	By header_ItNews = By.xpath("//*[@id='CaptionElementView']");
	By header_ItAwards = By.xpath("//*[@id=\"it-awards\"]");

	By heading_AllNews = By.xpath("//*[@id=\"vpc_WebPart.NewsWebPart.internal.a813dbd7-3b81-4a99-9943-dd816ccd522f\"]//div[@data-automation-id=\"newsItem\"]//a[@id='news_text_title']");
	By heading_AllAwards = By.xpath("//div[contains(@class,'itemArea')]");

	By txt_AwardContent = By.xpath("//div[@data-automation-id='textBox'][1]");
	//---------------------------------------------------------------->>>>>>>>>>>>>>>>>>

	
	//--------------------------ACTION METHODS--------------------------->>>>>>>>>>>>>>>>>>
	public boolean validate_appName() throws IOException
	{
		boolean flag = true;
		for (WebElement a : apps) 
		{
			String app_name = a.getText().trim();
			if (app_name.isEmpty()) 
			{
				flag = false;
				break;
			}
		}
		return flag;
	}
	public WebElement ITNews() throws InterruptedException, IOException
	{
		js.executeScript("document.querySelector(\"article[class='j_b_ada2ac09 j_b_ada2ac09 k_b_ada2ac09']>div>div\").scrollTop=700");
		Thread.sleep(2000);
		List<WebElement> list = driver.findElements(header_ItNews);
		WebElement News_header = list.get(1);

		ScreenShot.getScreenShot(driver);

		return News_header;
	}

	public WebElement ITAwards() throws InterruptedException, IOException
	{
		js.executeScript("document.querySelector(\"article[class='j_b_ada2ac09 j_b_ada2ac09 k_b_ada2ac09']>div>div\").scrollTop=1900");
		Thread.sleep(2000);
		WebElement awards = driver.findElement(header_ItAwards);

		ScreenShot.getScreenShot(driver);

		return awards;
	}

	public List<WebElement> News_HeaderTooltip() throws InterruptedException
	{
		js.executeScript("document.querySelector(\"article[class='j_b_ada2ac09 j_b_ada2ac09 k_b_ada2ac09']>div>div\").scrollTop=700");
		Thread.sleep(2000);
		List<WebElement> news_content = driver.findElements(heading_AllNews);
		System.out.println("Total No. of News " + news_content.size());

		return news_content;
	}

	public boolean ExtractAllAwards() throws InterruptedException, IOException
	{
		js.executeScript("document.querySelector(\"article[class='j_b_ada2ac09 j_b_ada2ac09 k_b_ada2ac09']>div>div\").scrollTop=1900");
		Thread.sleep(2000);

		List<WebElement> IT_awards = driver.findElements(heading_AllAwards);
		System.out.println(IT_awards.size());
		WebElement aw_btn;

		List<String> award_content = new ArrayList<String>(); // send the list to excel
		String award_info="";

		for(int i=1;i<=IT_awards.size();i++) 
		{
			try {
				Thread.sleep(2000);
				aw_btn = myWait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[contains(@class,'itemArea')]["+i+"]//a[@data-automation-id=\"newsItemTitle\"]")));

				ScreenShot.webelement_screenshot(aw_btn);
				Thread.sleep(1500);

				aw_btn.click();
				Thread.sleep(4000);
				award_info=myWait.until(ExpectedConditions.visibilityOfElementLocated(txt_AwardContent)).getText();
				award_content.add(award_info);   //System.out.println(award_info); // excel write;
				Thread.sleep(3000);

				ScreenShot.getScreenShot(driver);
				Thread.sleep(1500);

				driver.navigate().back();
				Thread.sleep(5000);
				js.executeScript("document.querySelector(\"article[class='j_b_ada2ac09 j_b_ada2ac09 k_b_ada2ac09']>div>div\").scrollTop=1900");
			}
			catch(Exception e) {
				return false;
			}
		}

		Excel.writeAwardContent(award_content);
		Thread.sleep(3000);

		return true;

	}
	//---------------------------------------------------------------->>>>>>>>>>>>>>>>>>
}
