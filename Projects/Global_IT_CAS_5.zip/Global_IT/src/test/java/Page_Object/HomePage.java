package Page_Object;

import java.io.IOException;
import java.time.Duration;
import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import Excel.Excel;
import Screen_Shot.ScreenShot;

public class HomePage extends BasePage {

	WebDriverWait myWait;
	JavascriptExecutor js;
	
	//--------------------------CONSTRUCTOR--------------------------->>>>>>>>>>>>>>>>>>
	public HomePage(WebDriver driver) {
		super(driver);
		myWait = new WebDriverWait(driver,Duration.ofSeconds(10));
		js=(JavascriptExecutor)driver;
	}
	//---------------------------------------------------------------->>>>>>>>>>>>>>>>>>
	
	//--------------------------PAGE OBJECT ELEMENTS--------------------------->>>>>>>>>>>>>>>>>>
	By btn_userInfo = By.xpath("//button[@id='O365_MainLink_Me']");
	By hlt_userInfo = By.xpath("//div[@class='mectrl_currentAccount']//div[3][1]");
	By username_element = By.id("mectrl_currentAccount_primary");
	By email_element = By.id("mectrl_currentAccount_secondary");
	By btn_corporate_functions = By.xpath("//div[contains(@class,'ms-OverflowSet ms-CommandBar-primaryCommand ')]//div[contains(@class,'ms-OverflowSet-item ')][6]");
	By ms_securityANDtechnology = By.xpath("//div[contains(@class,'ms-ContextualMenu')]//li[last()]");
	By btn_IT = By.xpath("//a[@name='IT']");
	//---------------------------------------------------------------->>>>>>>>>>>>>>>>>>
	
	//--------------------------ACTION METHODS--------------------------->>>>>>>>>>>>>>>>>>
//	public void open_url() throws InterruptedException
//	{
//		driver.get(" https://be.cognizant.com");
//		Thread.sleep(3000);
//	}
	
	public void info_btn_click() throws InterruptedException, IOException
	{
		ScreenShot.getScreenShot(driver); // screen shot
		
		driver.navigate().refresh();
		Thread.sleep(5000);
		WebElement user = myWait.until(ExpectedConditions.visibilityOfElementLocated(btn_userInfo));
		Thread.sleep(3000);
		js.executeScript("arguments[0].click();", user);
	}
	
	public void Higlight_UserInfo() throws InterruptedException, IOException
	{
		WebElement info = myWait.until(ExpectedConditions.visibilityOfElementLocated(hlt_userInfo));
	    js.executeScript("arguments[0].setAttribute('style','border:5px solid red;background:yellow')",info);
	    Thread.sleep(3000);
	    
	    ScreenShot.webelement_screenshot(info); // screenshot of user info 
	}
	
	public void fetching_userDetails() throws IOException, InterruptedException
	{
		String Username = myWait.until(ExpectedConditions.visibilityOfElementLocated(username_element)).getText();
		String Email = myWait.until(ExpectedConditions.visibilityOfElementLocated(email_element)).getText();
		
		String[] str = Username.split("[,\\s]+");
		int start = 0;
		int end = str.length-2;
		String temp="";
		while(start<end) {
			temp = str[start];
			str[start] = str[end];
			str[end] = temp;
			start++;
			end--;
		}
		Username = "";
		for(int i=0;i<str.length;i++)
		{
			Username += " " + str[i];
		}
		
		// Sending Details in the Excel File
		List<String> user_details = new ArrayList<String>();
		user_details.add(Username.trim());
		user_details.add(Email);
		Excel.writeUserDetails(user_details);
		Thread.sleep(2000);
	}
	
	public void click_CorporateFunction_IT() throws InterruptedException, IOException
	{
		Thread.sleep(3000);
		myWait.until(ExpectedConditions.visibilityOfElementLocated(btn_corporate_functions)).click();;
		//driver.findElement(btn_corporate_functions).click();
		Thread.sleep(1500);
		Actions act = new Actions(driver);
		   
		WebElement ST = myWait.until(ExpectedConditions.visibilityOfElementLocated(ms_securityANDtechnology));
		act.moveToElement(ST).perform();
		
		  
		//click on IT
		WebElement IT = myWait.until(ExpectedConditions.visibilityOfElementLocated(btn_IT));
		IT.click();
		Thread.sleep(3000);
	}
	
	//---------------------------------------------------------------->>>>>>>>>>>>>>>>>>

}
