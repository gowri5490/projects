package Excel;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.List;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class Excel {

	public static void writeUserDetails(List<String> list) throws IOException {
		String expath = "C:\\Users\\2319992\\OneDrive - Cognizant\\Desktop\\Global_IT\\Global_IT\\src\\test\\java\\Excel\\Output_UserDetails.xlsx";

		FileInputStream fis = new FileInputStream(expath);
		XSSFWorkbook wb = new XSSFWorkbook(fis);

		XSSFSheet sheet = wb.getSheet("sheet1");
		if (sheet == null) {
			sheet = wb.createSheet("sheet1");
		}

		Row row = sheet.createRow(0);
		row.createCell(0).setCellValue("USER DETAILS");

		int rowNumber = 1;
		for (String str : list) {
			row = sheet.createRow(rowNumber);
			row.createCell(0).setCellValue(str);

			rowNumber++;
		}

		FileOutputStream fos = new FileOutputStream(expath);
		wb.write(fos);
		wb.close();
		fos.close();
	}


	public static void writeAwardContent(List<String> list) throws IOException {
		String expath = "C:\\Users\\2319992\\OneDrive - Cognizant\\Desktop\\Global_IT\\Global_IT\\src\\test\\java\\Excel\\Output_Award_Content.xlsx";

		FileInputStream fis = new FileInputStream(expath);
		XSSFWorkbook wb = new XSSFWorkbook(fis);

		XSSFSheet sheet = wb.getSheet("sheet1");
		if (sheet == null) {
			sheet = wb.createSheet("sheet1");
		}

		Row row = sheet.createRow(0);
		row.createCell(0).setCellValue("AWARD CONTENT");

		int rowNumber = 1;
		for (String str : list) {
			row = sheet.createRow(rowNumber);
			row.createCell(0).setCellValue(str);

			rowNumber++;
		}

		FileOutputStream fos = new FileOutputStream(expath);
		wb.write(fos);
		wb.close();
		fos.close();
	}

	public static boolean check_ExcelFile(int f) throws IOException
	{
		String expath="";
		if(f==1)
		{
			expath = "C:\\Users\\2319992\\OneDrive - Cognizant\\Desktop\\Global_IT\\Global_IT\\src\\test\\java\\Excel\\Output_UserDetails.xlsx";
		}
		else
		{
			expath = "C:\\Users\\2319992\\OneDrive - Cognizant\\Desktop\\Global_IT\\Global_IT\\src\\test\\java\\Excel\\Output_Award_Content.xlsx";
		}
		try {
			FileInputStream fis = new FileInputStream(expath);
			@SuppressWarnings("resource")
			XSSFWorkbook wb = new XSSFWorkbook(fis);

			XSSFSheet sheet = wb.getSheetAt(0); // Assuming we are checking the first sheet
			if( (sheet.getLastRowNum() <= 0) && (sheet.getPhysicalNumberOfRows() <= 0) )
			{
				return true; // file empty
			}
			else
			{
				return false; // file non empty
			}
		} catch (Exception e) {
			return true;
		} 


	}
}
