package outreach;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.ArrayList;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class ExcelUtility 
{

	private static final String DATA_SHEET_PATH = "./src/test/resources/DataSheet.xlsx";

	// Extracts and returns the search term from the specified Excel file
	public static ArrayList<String> getSearchTerm() 
	{
		ArrayList<String> searchTerms = new ArrayList<String>();
		try {
			FileInputStream inputStream = new FileInputStream(DATA_SHEET_PATH);
			XSSFWorkbook workbook = new XSSFWorkbook(inputStream);
			XSSFSheet sheet = workbook.getSheetAt(0);// Get the first sheet
			for(int i=0;i<7;i++)
			{
				XSSFRow row = sheet.getRow(i); // Get the first row
				XSSFCell cell = row.getCell(0); // Get the first cell

				if (cell != null) {
					searchTerms.add(cell.getStringCellValue());
				}
			}
			workbook.close();

		} 
		catch (IOException e) 
		{
			System.out.println("Error reading search file: " + e.getMessage());
		}

		return searchTerms;


	}
}
