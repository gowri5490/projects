package outreach;

import java.time.Duration;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class Onecognizant 
{
	  //declaring a driver
	  public WebDriver driver;
     
	  //assigning driver by a constructor
      Onecognizant(WebDriver driver)
      {
   	  this.driver = driver;
   	  driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(3));
   	  PageFactory.initElements(driver,this);
   	  }
      
      //capturing web element of search bar
      @FindBy(xpath = "//input[@placeholder='Search this site...']")
      WebElement searchbar;
      
      //capturing web element of search icon
      @FindBy(xpath = "//div[@class='searchInputIcon']")
      WebElement searchicon;
      
      //capturing web element of search icon in edge browser
      @FindBy(xpath = "//li[@class='searchTopBar']")
      WebElement searchiconred;
      
      //capturing web element of search bar in edge browser
      @FindBy(xpath = "//*[@id=\"oneCSearchTop\"]")
      WebElement searchbared;
      
      @FindBy(xpath = "//*[@id=\"DesktopPlatformBar\"]/div[4]/div/div[3]")
      WebElement searchiconed;
      
      //capturing web element of outreach
      @FindBy(xpath = "//div[contains(text(),'Outreach')and @class='appsResultText']")
      WebElement outreach;
      
      //capturing web element of close search button
      @FindBy(xpath = "//div[@aria-label='Close search results']")
      WebElement closesearch;
      
      //defining method for searching in either chrome or edge
      public void search(String br)
      {
    	  if(br.equals("chrome"))
    		  searchbar.sendKeys("outreach");
    	  else if(br.equals("edge")) {
    		  searchiconred.click();
    		  searchbared.sendKeys("outreach");
    	  }
      }
      
      //defining method for clicking search icon in either chrome or edge
      public void clicksearch(String br)
      {
    	  if(br.equals("chrome"))
    		  searchicon.click();	
    	  else if(br.equals("edge"))
    		  searchiconed.click();
      }
      
      //defining method for clicking outreach
      public void clickoutreach()
      {
    	  outreach.click();
      }
      
      //defining method for clicking close search
      public void clickclose()
      {
    	  closesearch.click();
      }
      
      
}
