package outreach;


import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.io.FileHandler;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class Outreach 
{
	//declaring driver,location,event type,week
	public WebDriver driver;
	public String locoption;
	public String eveoption;
	public String weekoption;
	static int imgcount=1;

    //assigning driver by a constructor
	Outreach(WebDriver driver)
	{
		this.driver=driver;
		PageFactory.initElements(driver,this);
	}
	
	//assigning location and other details by a constructor
	Outreach(WebDriver driver,String locoption,String eveoption,String weekoption)
	{
		this.driver=driver;
		PageFactory.initElements(driver,this);
		this.locoption=locoption;
		this.eveoption=eveoption;
		this.weekoption=weekoption;
    }
	
    //capturing web element of frame
	@FindBy(id = "appFrame")
	WebElement frame;

	//capturing web element of menu
	@FindBy(xpath = "//ul[@class='navbar-nav paddingleft5']")
	WebElement menu;

	//capturing web element of Event drop down
	@FindBy(xpath="//span[@class='vieweventDrop']")
	WebElement eventDrop;
    
	//capturing web element of location text box
	@FindBy(xpath="//button[@data-id='jsonBaseLocation']")
	WebElement locationTextBox;
    
	//capturing web element of event type
	@FindBy(xpath="//button[@data-id='jsonEventType']")
	WebElement eventType;

	//capturing web element of event type
	@FindBy(xpath="//button[@data-id='jsonWeekType']")
	WebElement weekType;

	//capturing web element of from date
	@FindBy(id="fromDate")
	WebElement fromDate;

	//capturing web element of To date
	@FindBy(id="toDate")
	WebElement toDate;

	//capturing web element of event search
	@FindBy(id="Viewallsearch")
	WebElement eventHomeSearch;

	//capturing web element of search events
	@FindBy(xpath="//div[@id='divsearchevents']")
	WebElement divtext;

	//capturing web element of home button
	@FindBy(xpath = "//*[@id=\"homebutton\"]")
	WebElement homeBtn;
	
    //defining method for returning frame 
	public WebElement getFrame()
	{
		return frame;
	}

	//defining method for returning menu
	public WebElement getMenu()
	{
		return menu;
	}

	//defining method for clicking event drop down
	public void clickEventDrop()
	{
		eventDrop.click();
	}

	//defining method for clicking location text box
	public void clickLocationTextbox()
	{
		locationTextBox.click();
	}

	//defining method for clicking location
	public void clickLocation()
	{
		By loc=By.xpath("//a[descendant::span[contains(text(),'"+locoption+"')]]");
		WebElement locationSel = driver.findElement(loc);
		locationSel.click();
	}

	//defining method clicking event type text box
	public void clickEventTextbox()
	{
		eventType.click();
	}

	//defining method for clicking event type
	public void clickEventType()
	{
		By loc1=By.xpath("//a[descendant::span[contains(text(),'"+eveoption+"')]]");
		WebElement eventTypeSel = driver.findElement(loc1);
		eventTypeSel.click();
	}

	//defining method for clicking week type text box
	public void clickWeekTextbox()
	{
		weekType.click();
	}

	//defining method for clicking week type
	public void clickWeekType()
	{
		By loc2=By.xpath("//a[descendant::span[contains(text(),'"+weekoption+"')]]");
		WebElement weekSel = driver.findElement(loc2);
		weekSel.click();
	}

	//defining method for returning from date
	public WebElement getFromDate()
	{
		return fromDate;
	}

	//defining method for returning To date
	public WebElement getToDate()
	{
		return toDate;
	}

	//defining method for clicking home search
	public void clickSearch()
	{
		eventHomeSearch.click();
	}

	//defining method for returning event details
	public String getEventDetails()
	{
		return divtext.getText();
	}

	//defining method for clicking home button
	public void clickRefresh()
	{
		homeBtn.click();
	}

	//defining method for taking screenshot and storing
	public void Screenshot()
	{
		try 
		{

			// Takes screenshot
			File firstsrc = ((RemoteWebDriver) driver).getScreenshotAs(OutputType.FILE);

			// Destination to store
			File dest = new File("./src/Screenshots/img"+imgcount+".png");

			// Saves at destination
			FileHandler.copy(firstsrc,dest);

			// Increment image number
			imgcount++;

		} 
		catch (IOException e) 
		{

			// Write the result to excel and file, print result into console
			System.out.println("There was problem taking Screenshot");
		}
		
	}
	
	    //defining method for writing output in text file
		public static int count=0;
		public void writeToFile(String textToWrite) {
			if(count==0)
			{
				try  {
					FileWriter writer = new FileWriter("./src/test/resources/OutputData.txt");
					writer.write(textToWrite);
					writer.write("\n");
					writer.close();
				} catch (Exception e) {
					System.out.println("Error writing to file: ");
				}
			}
			else
			{
				try{
					FileWriter writer = new FileWriter("./src/test/resources/OutputData.txt",true); 
					writer.append(textToWrite);
					writer.append("\n");
					writer.close();
				} catch (Exception e) {
					System.out.println("Error writing to file: ");
				}
			}
			count++;
		}
	}

