package outreach;

import java.text.SimpleDateFormat;
import java.time.Duration;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.interactions.Actions;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

public class OutreachTest 
{
      WebDriver driver;
      Becognizant bc;
      Onecognizant oc;
      Outreach or;
      int count=0;
      Actions Act;
      String fromdate,todate,divtext;
      ArrayList<String> searchterms;
      WebElement ele;
     
      //method annotated as before class for setting up driver,opening be cognizant,one cognizant,and outreach
      @BeforeClass
      @Parameters({"browser","url"})
      void DriverSetup(String br,String appurl) throws InterruptedException
      {
    	  //opening web page in chrome browser
    	  if(br.equals("chrome")) 
    	  {
    		  driver = new ChromeDriver(); 
    		  or = new Outreach(driver);
    		  System.out.println("Test running in Chrome Browser");
    		  or.writeToFile("\nTest running in Chrome Browser\n");
    	  }
    	  //opening web page in edge browser
    	  else if(br.equals("edge")) 
    	  {
    		  driver = new EdgeDriver();
    		  or = new Outreach(driver);
    		  System.out.println("Test running in Edge Browser");
    		  or.writeToFile("Test running in Edge Browser\n");
    	  }
    	  driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(3));
    	  driver.get(appurl);
    	  driver.manage().window().maximize();
    	  Thread.sleep(1000);
    	  
    	  //Taking screenshot
    	  or.Screenshot();
    	  
    	  //getting current window handle
    	  String currentId = driver.getWindowHandle();
    	  bc = new Becognizant(driver);
    	  
    	  //Getting user details
          bc.getUserDetails();
          
          or.Screenshot();
          
          //clicking one cognizant
          bc.clickOneC();  	  
    	
    	  //switching driver to new window
    	  for(String newId : driver.getWindowHandles())
  		 {
  			if(!newId.equals(currentId))
  			{
  				driver.switchTo().window(newId);
  			}
  		 }
    	  oc = new Onecognizant(driver);
    	  Thread.sleep(1000);
    	  or.Screenshot();
    	  
    	  //searching outreach
    	  oc.search(br);
    	  
    	  oc.clicksearch(br);
    	  
    	  //clicking outreach
    	  oc.clickoutreach();
    	  
    	  oc.clickclose();
    	  Thread.sleep(1000);
    	  or.Screenshot();
    	  
    	  //switching to iframe
    	  driver.switchTo().frame(or.getFrame());
    	  
    	  //assigning current date as From date and 4 days after current date as To date
    	  Date fdate = new Date();
  		  long ltime =fdate.getTime()+4*24*60*60*1000;
  		  Date tdate = new Date(ltime);
  		  SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
  		  fromdate = sdf.format(fdate);
  		  todate = sdf.format(tdate);
  		  searchterms=ExcelUtility.getSearchTerm();
    	  
      }
      
      //performing first test case as printing menus and sub menus
      @Test(priority=-1)
      void TC_MF_001()
      {
    	    Act = new Actions(driver);
    	    int c=0;
    	    WebElement element=or.getMenu();
			List<WebElement> li_list = element.findElements(By.tagName("li"));
			for(WebElement x:li_list)
			{
				if(c==0)
					ele=x;
				
				Act.moveToElement(x).build().perform();
				or.Screenshot();
				System.out.println("Menu: "+x.findElement(By.tagName("a")).getText());
				or.writeToFile("Menu: "+x.findElement(By.tagName("a")).getText());
				if(c!=1) {
				System.out.println("SubMenus: "+"\n"+x.findElement(By.tagName("div")).getText());
				or.writeToFile("SubMenus: "+"\n"+x.findElement(By.tagName("div")).getText());
				}
				System.out.println();
				or.writeToFile("\n");
				c++;
			}
			driver.findElement(By.xpath("//*[@id=\"homebutton\"]")).click();
      }
      
    //performing second test case as printing "Events based on your interests" in outreach  
    @Test(priority=0)
  	void TC_ED_001() {
    	try {
  		divtext = driver.findElement(By.xpath("//div[@class='sectiontitle']")).getText();} catch(Exception e) {}
  		Assert.assertEquals(divtext,searchterms.get(0) );//"Event Based on your Interests"
  	} 
    
    //performing third test case as searching events by filtering and entering chennai as location
    @Test(priority=1)
    void TC_EF_001() throws InterruptedException {
  	     Actions Act1 = new Actions(driver);
  	     WebElement ele1= driver.findElement(By.xpath("/html/body/div[1]/nav/ul/li[1]"));
    	 Act1.moveToElement(ele1).build().perform();
    	 ele1.findElement(By.tagName("div")).click();
    	 Outreach or = new Outreach(driver,searchterms.get(1),searchterms.get(2),searchterms.get(3));
    	 or.clickEventDrop();
    	 or.clickLocationTextbox();
    	 or.clickLocation();
    	 or.clickEventTextbox(); 
    	 or.clickEventType();
    	 or.clickWeekTextbox();
    	 or.clickWeekType();
    	 or.getFromDate().sendKeys(fromdate);
    	 or.getToDate().sendKeys(todate);
    	 or.clickSearch();
    	 System.out.println("Event Details in "+searchterms.get(1)+",");
    	 or.writeToFile("Event Details in "+searchterms.get(1)+",");
   		 Thread.sleep(1000);
   		 or.Screenshot();
   		 divtext = or.getEventDetails();
   		 or.clickRefresh();
    }
    
    //performing fourth test case as searching events by filtering and entering bangalore as location
    @Test(priority=2)
    void TC_EF_002() throws InterruptedException 
    {   Actions Act1 = new Actions(driver);
	     WebElement ele1= driver.findElement(By.xpath("/html/body/div[1]/nav/ul/li[1]"));
	    Act1.moveToElement(ele1).build().perform();
	   ele1.findElement(By.tagName("div")).click();
    	Outreach or = new Outreach(driver,searchterms.get(4),searchterms.get(5),searchterms.get(6));
    	or.clickEventDrop();
    	or.clickLocationTextbox();
    	or.clickLocation();
    	or.clickEventTextbox(); 
    	or.clickEventType();
    	or.clickWeekTextbox();
    	or.clickWeekType();
    	or.getFromDate().sendKeys(fromdate);
    	or.getToDate().sendKeys(todate);
    	or.clickSearch();
    	System.out.println("Event Details in "+searchterms.get(4)+",");
    	or.writeToFile("Event Details in "+searchterms.get(4)+",");
    	Thread.sleep(1000);
    	or.Screenshot();
    	divtext = or.getEventDetails();
    	or.clickRefresh();

    }
     
    //performing fifth test case as printing cards under volunteers around me
    @Test(priority=3)
    void TC_CD_001() throws InterruptedException
    {   
    	int c=1;
    	driver.findElement(By.xpath("//a[@class='nav-link']")).click();
		driver.findElement(By.id("divvolteer")).click();
		JavascriptExecutor executor = (JavascriptExecutor)driver;
		executor.executeScript("window.scroll(0,1000)");
		List<WebElement> l = driver.findElements(By.xpath("//div[@class='profilevoltext']"));
		Thread.sleep(1000);
		or.Screenshot();
		for(WebElement i:l) 
		{
			System.out.print("Card No: "+c+" ");
			or.writeToFile("Card No: "+c+" ");
			System.out.println(i.getText());
			or.writeToFile(i.getText());
			c++;
		}
    }
    
    //printing event details after method
    @AfterMethod
    void printDetails() {
    	
    	if(count>0&&count<4)
    	{
    	try {
    	String arr[]= divtext.split("Register");
		if(!arr[0].equals("No Events to display")&& arr[0]!="" && !arr[0].equals("Event Based on your Interests")) {
		int count=1;
		for(String x:arr) {
			if(count==1) {
				System.out.print("Event No:"+count+"\n");
				or.writeToFile("Event No:"+count+"\n");
			}
			else {
				System.out.print("Event No:"+count);
				or.writeToFile("Event No:"+count);
			}
			System.out.println(x);
			or.writeToFile(x);
			count++;
		 }
		}
		else {
			System.out.println(arr[0]+"\n");
			or.writeToFile(arr[0]+"\n");
		}
    } catch(Exception e) {}
    	}
    	count++;
    }
    
    
    //quitting driver 
    @AfterClass
      void tearDown()
      {
    	  driver.quit();
      }
}
