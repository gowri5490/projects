package outreach;

import java.time.Duration;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class Becognizant
{
	//Declaring a driver
	public WebDriver driver;

	//Assigning driver by a constructor
	Becognizant(WebDriver driver)
	{
		this.driver = driver;
		PageFactory.initElements(driver,this);
    }

	//capturing web element for one cognizant
	@FindBy(xpath ="//div[contains(text(),'OneCognizant')]")
	WebElement onecognizant;

	//capturing web element for user information
	@FindBy(xpath="//*[@id='O365_MainLink_Me']")
	WebElement userinfo;

	//capturing web element for user name
	@FindBy(xpath="//*[@id='mectrl_currentAccount_primary']") 
	WebElement label_username_loc;

	//capturing web element for email id
	@FindBy(xpath="//*[@id='mectrl_currentAccount_secondary']") 
	WebElement label_email_loc;
	
	By helpbutton=By.xpath("//*[@id='O365_MainLink_Help']");

	By username=By.xpath("//*[@id='mectrl_currentAccount_primary']");

	//defining method for clicking one cognizant
	public void clickOneC() 
	{	
		driver.navigate().refresh();
		onecognizant.click();
	}

	//defining method for printing user details
	public void getUserDetails() throws InterruptedException
	{ 
		WebDriverWait mywait = new WebDriverWait(driver,Duration.ofSeconds(20));
		mywait.until(ExpectedConditions.elementToBeClickable(helpbutton));  //wait till help button displayed
		Thread.sleep(5000);
		userinfo.click();
		mywait.until(ExpectedConditions.visibilityOfElementLocated(username));  //wait till user name displayed
		System.out.println(label_username_loc.getText());
		System.out.println(label_email_loc.getText());
	}
}
