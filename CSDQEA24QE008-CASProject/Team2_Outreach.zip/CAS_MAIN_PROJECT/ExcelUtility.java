package outreach;

import java.io.FileInputStream;
import java.io.IOException;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class ExcelUtility {
	
	 private static final String DATA_SHEET_PATH = "./src/Inputs/DataSheet.xlsx";

	    // Extracts and returns the search term from the specified Excel file
	    public static String getSearchTerm() {
	        String searchTerm = null;
	        try (
	                FileInputStream inputStream = new FileInputStream(DATA_SHEET_PATH);
	                XSSFWorkbook workbook = new XSSFWorkbook(inputStream)
	        ) {
	            XSSFSheet sheet = workbook.getSheetAt(0); // Get the first sheet
	            XSSFRow row = sheet.getRow(0); // Get the first row
	            XSSFCell cell = row.getCell(0); // Get the first cell

	            if (cell != null) {
	                searchTerm = cell.getStringCellValue();
	            }
	        } catch (IOException e) {
	            System.out.println("Error reading search file: " + e.getMessage());
	        }

	        return searchTerm;
	

}
