package driverUtility;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Parameters;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
public class DriverSetup {
      public static Logger l; 
      public static WebDriver driver;

	@BeforeClass
	@Parameters({"browser"})
	public void driverSetup(String browserName){
		l=LogManager.getLogger(getClass());

		if(browserName.equalsIgnoreCase("chrome")) {
			l.info("---> Starting chrome");
			driver = new ChromeDriver();
		}else if(browserName.equalsIgnoreCase("edge")){
			l.info("---> Starting edge");
			driver = new EdgeDriver();
		}else {
			//System.out.println("Invalid Browser");
			l.info("Invalid Browser");
		}
	}
	@AfterClass
	public void browserClose() {
		l.info("--->closing the browser");
		l.info(" ");
		driver.quit();
	}
	public String captureScreen(String ssName) throws IOException {

		String timeStamp = new SimpleDateFormat("yyyyMMddhhmmss").format(new Date());
				
		TakesScreenshot takesScreenshot = (TakesScreenshot) driver;
		File sourceFile = takesScreenshot.getScreenshotAs(OutputType.FILE);
		
		String targetFilePath=System.getProperty("user.dir")+"\\screenshots\\" + ssName + "_" + timeStamp + ".png";
		File targetFile=new File(targetFilePath);
		
		sourceFile.renameTo(targetFile);
		
		return targetFilePath;

	}


}
