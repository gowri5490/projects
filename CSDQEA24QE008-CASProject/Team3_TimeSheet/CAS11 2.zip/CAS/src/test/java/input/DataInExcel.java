package input;
import java.io.IOException;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class DataInExcel {

	public static String getinput() {
		
		String value="";
		try {
			@SuppressWarnings("resource")
			XSSFWorkbook work = new XSSFWorkbook("./src/Input/Input.xlsx");
			XSSFSheet sheet = work.getSheet("Sheet1");
			XSSFRow row = sheet.getRow(sheet.getPhysicalNumberOfRows()-1);
			XSSFCell cell = row.getCell(row.getPhysicalNumberOfCells()-1);
			value = cell.toString();
			
		} catch (IOException e) {
		}
		return value;
	}
	
	@SuppressWarnings("null")
	public static String[] getDropDownValue() {
		String[] dropDrownValue = new String[7];
		try {
			@SuppressWarnings("resource")
			XSSFWorkbook work = new XSSFWorkbook("./src/Input/Input.xlsx");
			XSSFSheet sheet = work.getSheet("Sheet2");
			XSSFRow row = sheet.getRow(sheet.getPhysicalNumberOfRows()-1);
			for(int i=0;i<dropDrownValue.length;i++) {
				XSSFCell cell = row.getCell(row.getFirstCellNum()+i);
				dropDrownValue[i] = cell.toString();
			}
			
		}catch (IOException e) {
		}
		return dropDrownValue;
	}

}
