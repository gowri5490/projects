package input;

import java.io.FileReader;
import java.io.IOException;
import java.util.Properties;
public class Url {
	public static String getUrl() {
		 String url="";
		try {
			FileReader file = new FileReader("./src/Input/Properties.properties");
			Properties p = new Properties();
			p.load(file);
			url = p.getProperty("url");

		} catch (IOException e) {

		}
		return url;
	}
	public static void main(String[] a) {
		System.out.println(getUrl());
	}

}
