package timeSheet;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.Select;
import org.testng.Assert;
import org.testng.annotations.Test;

import output.ScreenShot;
import pageObjects.OneCognizant;

public class TestCase3 extends TestCase1{
	@Test(priority=3)
	public static void searchByDate() throws InterruptedException {
		l.info("Validating the particular date");
		WebDriver driver = OneCognizant.oneCognizant();
		
		Select searchBy = new Select(driver.findElement(By.className("ps-dropdown")));
		searchBy.selectByIndex(1);
		
//		Date curdate=new Date();
		SimpleDateFormat formatter = new SimpleDateFormat("MM/dd/yyyy");
		Date curdate=new Date();
		String str = formatter.format(curdate);
		l.info("current date = "+str);
		
		Thread.sleep(2000);
		driver.findElement(By.className("ps-edit")).sendKeys(str);
		driver.findElement(By.xpath("//a[@class='ps-button' and text()='Search']")).click();
		String dateSort = driver.findElement(By.xpath("//div[@class='ps_box-link timesheet_period']")).getText();
		l.info("takenDate = "+dateSort);
		
		Calendar calendar = Calendar.getInstance();
		DateFormat dateFormat = new SimpleDateFormat("dd-MMM-yyyy", Locale.getDefault());
		String givenStartDate = dateSort.substring(0, 11);
		String givenEndDate = dateSort.substring(15, 26);
		SimpleDateFormat sdf = new SimpleDateFormat("dd-MMM-yyyy");
		try {
			Date startDate = (Date) sdf.parse(givenStartDate);
			Date endDate = (Date) sdf.parse(givenEndDate);
			// Check if start date is Saturday
			Calendar startCalendar = Calendar.getInstance();
			startCalendar.setTime(startDate);
			if (startCalendar.get(Calendar.DAY_OF_WEEK) == Calendar.SATURDAY) {
				l.info("Start date is a Saturday");
			} else {
				l.info("Start date is not a Saturday");
			}
			// Check if end date is Friday
			Calendar endCalendar = Calendar.getInstance();
			endCalendar.setTime(endDate);
			if (endCalendar.get(Calendar.DAY_OF_WEEK) == Calendar.FRIDAY) {
				l.info("End date is a Friday");
			} else {
				l.info("End date is not a Friday");
			}
			// Check if start and end together form a complete week
			if (startCalendar.get(Calendar.DAY_OF_WEEK) == Calendar.SATURDAY&& endCalendar.get(Calendar.DAY_OF_WEEK) == Calendar.FRIDAY) {
				l.info("Start and end together form a complete week");
			} else {
				l.info("Start and end do not form a complete week");
			}
			boolean Status = true;
			Assert.assertEquals(Status, true);
            Thread.sleep(2000);
            ScreenShot.takeScreenshot(driver);
		}
		catch (Exception e) {
			System.out.println(e);
			// TODO: handle exception
		}
//		String[] va = dateSort.split("To ");
//		String g = va[0].toLowerCase();
//		String gg = va[1].toLowerCase();
//		StringBuffer values = new StringBuffer(g).replace(3, 4, String.valueOf(g.charAt(3)).toUpperCase());
//		StringBuffer value = new StringBuffer(gg).replace(3, 4, String.valueOf(gg.charAt(3)).toUpperCase());			
//	
//		String from = String.valueOf(values).trim();
//		String to = String.valueOf(value).trim();
// 
//    	// Subtract 7 days to get the start date of the previous week (Saturday)
//		calendar.set(Calendar.DAY_OF_WEEK, Calendar.SATURDAY);
////        calendar.add(Calendar.DATE, 0);
//        String weekStartDate = dateFormat.format(calendar.getTime());
//        System.out.println("Week Start Date = " + weekStartDate);
//        
//        System.out.println(weekStartDate.equals(from));
//        Assert.assertEquals(weekStartDate, from);
//
//
//        // Add 6 days to get the end date (Friday) of the previous week
//        calendar.add(Calendar.DATE, 6);
//        String weekEndDate = dateFormat.format(calendar.getTime());
//        System.out.println("Week End Date = " + weekEndDate);
//        
       // System.out.println(weekEndDate.equals(to));
        //Assert.assertEquals(weekEndDate, to);     
	}

}
