package timeSheet;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.List;
import java.util.Locale;
import java.util.Date;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.Assert;
import org.testng.annotations.Test;

import output.ScreenShot;
import pageObjects.OneCognizant;

public class TestCase2 extends TestCase1{
	@Test(priority=2)
	public void dateInWeek() throws Exception {
		l.info("Validating all the weeks");
		 WebDriver driver = OneCognizant.oneCognizant();
		
		Thread.sleep(2000);
		List<WebElement> day=driver.findElements(By.xpath("//div[@class='ps_box-link timesheet_period']"));
		
		String[] weeks = new String[3];
		
		for (int i = 0; i < 3; i++) {
			l.info(day.get(i).getText());
			String d1 = day.get(i).getText();
			String givenStartDate = d1.substring(0, 11);
			String givenEndDate = d1.substring(15, 26);
			SimpleDateFormat sdf = new SimpleDateFormat("dd-MMM-yyyy");
			try {
				Date startDate = (Date) sdf.parse(givenStartDate);
				Date endDate = (Date) sdf.parse(givenEndDate);
				// Check if start date is Saturday
				Calendar startCalendar = Calendar.getInstance();
				startCalendar.setTime(startDate);
				if (startCalendar.get(Calendar.DAY_OF_WEEK) == Calendar.SATURDAY) {
					l.info("Start date is a Saturday");
				} else {
					l.info("Start date is not a Saturday");
				}
				// Check if end date is Friday
				Calendar endCalendar = Calendar.getInstance();
				endCalendar.setTime(endDate);
				if (endCalendar.get(Calendar.DAY_OF_WEEK) == Calendar.FRIDAY) {
					l.info("End date is a Friday");
				} else {
					l.info("End date is not a Friday");
				}
				// Check if start and end together form a complete week
				if (startCalendar.get(Calendar.DAY_OF_WEEK) == Calendar.SATURDAY
&& endCalendar.get(Calendar.DAY_OF_WEEK) == Calendar.FRIDAY) {
					l.info("Start and end together form a complete week");
				} else {
					l.info("Start and end do not form a complete week");
				}
				boolean Status = true;
				Assert.assertEquals(Status, true);
        Thread.sleep(2000);
		ScreenShot.takeScreenshot(driver);
			}
			catch (Exception e) {
				// TODO: handle exception
			}
		
		
	}

	}
}
