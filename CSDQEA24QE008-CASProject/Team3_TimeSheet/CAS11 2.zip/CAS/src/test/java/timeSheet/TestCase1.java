package timeSheet;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.testng.Assert;
import org.testng.annotations.Test;
import output.ScreenShot;
import pageObjects.BeCognizant;

public class TestCase1 extends BeCognizant{
	@Test(priority=1)
	public void  userValidate() throws InterruptedException{
		l.info("Validating the userDetails");
		WebDriver driver = BeCognizant.beCognizant();
		
		Actions act=new Actions(driver);
		WebElement profileElement = driver.findElement(By.id("O365_MainLink_Me"));
		act.moveToElement(profileElement).click().perform();
		Thread.sleep(2000);
		act.moveToElement(profileElement).doubleClick().perform();
		Thread.sleep(2000);
		String userDetails = driver.findElement(By.id("mectrl_currentAccount_secondary")).getText();
		l.info(userDetails +": "+userDetails.contains("@cognizant.com"));
		Assert.assertTrue(userDetails.contains("@cognizant.com"));
		Thread.sleep(2000);
		ScreenShot.takeScreenshot(driver);
	}

}
