package timeSheet;
import java.time.Duration;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;
import org.testng.Assert;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import input.DataInExcel;
import output.ScreenShot;
import pageObjects.OneCognizant;


public class TestCase4 extends TestCase1 {
protected static WebDriver driver;
	
	
	@Test(priority=4)
	public static void driver() {
		l.info("validating the each status");
		driver  = OneCognizant.oneCognizant();
	}
	
	@Test(priority = 5, dataProvider="sbo", dependsOnMethods="driver")
	public static void statusSort(String options) throws InterruptedException {

		Select searchBy = new Select(driver.findElement(By.id("CTS_TS_LAND_WRK_CTS_TS_SEARCH")));
		searchBy.selectByIndex(2);
		

		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		Select status = new Select(driver.findElement(By.xpath("//div[@class='ps_box-dropdown select_status']//select")));
		status.selectByVisibleText(options);
		driver.findElement(By.xpath("//a[@class='ps-button' and text()='Search']")).click();
		
		try {

			driver.findElement(By.id("#ICOK$span")).click();
			l.info(driver.findElement(By.id("CTS_TS_LAND_PER_DESCR30$0")).getText());

		}catch(Exception e) {
			Thread.sleep(2000);
			List<WebElement>approveWebElement=driver.findElements(By.xpath("//div[@class='ps_pspagecontainer']//div[@class='ps_box-scrollarea-row']"));
			l.info("No of Items = "+approveWebElement.size());
			for(WebElement web : approveWebElement) {
				String st=web.findElement(By.xpath("//div[@class='ps_box-scrollarea-row']/div[2]/div[2]/div[2]/span")).getText();
				l.info(st.equals(driver.findElement(By.xpath("//div[@class='ps_box-dropdown select_status']//option[@selected='selected']")).getText()));
				Assert.assertTrue(st.equals(driver.findElement(By.xpath("//div[@class='ps_box-dropdown select_status']//option[@selected='selected']")).getText()));
			
			}
			 
		}
		Thread.sleep(2000);
		ScreenShot.takeScreenshot(driver);
	}
	
	
	@DataProvider(name="sbo")
	public String[] searchByOptions() {
				
		
		String[] options = DataInExcel.getDropDownValue();
		
		return options;
		
	}

}
