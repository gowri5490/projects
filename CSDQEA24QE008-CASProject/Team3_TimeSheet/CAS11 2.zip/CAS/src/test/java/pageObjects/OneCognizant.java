package pageObjects;
import java.time.Duration;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Wait;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Test;

import driverUtility.DriverSetup;
import input.DataInExcel;
import timeSheet.TestCase1;

public class OneCognizant extends TestCase1{
	public static WebDriver oneCognizant() {
		try {
		driver = BeCognizant.beCognizant();
		
		//opening one cognizant
		//driver.findElement(By.xpath("//div[text()='OneCognizant']")).click();
        JavascriptExecutor js = (JavascriptExecutor) driver;
		WebElement seemore = driver.findElement(By.xpath("//*[@id=\"5d7d4eec-cbe0-4c55-ae2e-f38d926d82a0\"]/div/div/div/p/span"));
		js.executeScript("arguments[0].scrollIntoView();",seemore);
		driver.findElement(By.xpath("//div[text()='OneCognizant']")).click();
		l.info("Starting OneCognizant");
		//driver.navigate().to("https://onecognizant.cognizant.com/Home?GlobalAppId=926");
		//switching window to one cognizant using windowhandles
		Set<String> windowsSet = driver.getWindowHandles();
		List<String> windowsList = new ArrayList<String>(windowsSet);
		//System.out.println(windowsList);
		Thread.sleep(2000);
		driver.switchTo().window(windowsList.get(1));
		
		
		Wait<WebDriver> wait = new WebDriverWait(driver,Duration.ofSeconds(10));
		wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.id("oneC_searchAutoComplete"))));
		//Thread.sleep(2000);
		driver.findElement(By.id("oneC_searchAutoComplete")).sendKeys(DataInExcel.getinput(),Keys.ENTER);
		//opening timesheet
//		wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.className("quickActionsResultText"))));
		Thread.sleep(2000);
		driver.findElement(By.xpath("//div[@id='newSearchQALST']//div[text()='View Timesheet']")).click();
		l.info("Starting TimeSheet");
		l.info("");
		//switching window to timesheet 
		Thread.sleep(2000);
		windowsList = new ArrayList<String>(driver.getWindowHandles());
		Thread.sleep(2000);
		driver.switchTo().window(windowsList.get(2));
		}catch(Exception e) {
			System.out.println(e);
		}
		return driver;
	}

}
