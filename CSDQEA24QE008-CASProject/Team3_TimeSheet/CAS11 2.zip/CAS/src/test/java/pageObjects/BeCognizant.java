package pageObjects;
import java.time.Duration;
import org.openqa.selenium.WebDriver;
import driverUtility.DriverSetup;
import input.Url;

public class BeCognizant extends DriverSetup{
	
	public static WebDriver beCognizant() throws InterruptedException {
		l.info("starting BeCognizant");
		String url=Url.getUrl();
		driver.get(url);
		Thread.sleep(500);
		driver.manage().window().maximize();

		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		
		return driver;
	}

}
